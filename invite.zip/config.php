<?php
/**
 * Created by PhpStorm.
 * User: huqi1
 * Date: 2018/1/25
 * Time: 20:28
 */
//config is used to config the invite system
$config=array(
    "SQL_URL"=>"localhost",
    "SQL_User"=>"test1",
    "SQL_Password"=>"FDE3Lnp4DC",
    "SQL_Port"=>"3306",
    "SQL_Database"=>"test1",
    "url"=>"http://pttest.spcsky.com/invite",//invite system main file url

);
//ptConfig is config the invite system link to the pt system
$ptConfig=array(
    "SQL_URL"=>"localhost",
    "SQL_User"=>"pt_spcsky_com",
    "SQL_Password"=>"RbFTjjec2f",
    "SQL_Port"=>"3306",
    "SQL_Database"=>"pt_spcsky_com",
    "url"=>"http://pttest.spcsky.com",//pt main file url
);
?>